//
//  Lab01StarWarsApp.swift
//  Lab01StarWars
//
//  Created by Matias Yliluoma on 27.4.2023.
//

import SwiftUI

@main
struct Lab01StarWarsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
